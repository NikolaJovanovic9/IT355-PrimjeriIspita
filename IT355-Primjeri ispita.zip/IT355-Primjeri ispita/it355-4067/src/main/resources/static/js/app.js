const deleteButtons = document.querySelectorAll('.btn-delete');

deleteButtons.forEach(button => {
    button.addEventListener('click', event => {
        const reservationId = event.target.id;
        fetch(`http://localhost:8080/api/reservations/${reservationId}`, {
            method: 'DELETE'
        }).then(response => {
            event.target.parentElement.parentElement.remove();
        });
    });
});

const reservationButtons = document.querySelectorAll('.btn-reservation');

reservationButtons.forEach(button => {
    button.addEventListener('click', event => {
        const id = event.target.id;
        const userId = id.split('-')[0];
        const productId = id.split('-')[1];
        fetch(`http://localhost:8080/api/reservations?userId=${userId}&productId=${productId}`, {
            method: 'POST'
        }).then(response => {
            event.target.parentElement.parentElement.remove();
            const container = document.getElementById('container');
            container.innerHTML += "<div><div class='met-alert alert-success'>Rezervacija kreirana!</div></div>";
        }).catch((err) => {
            console.log(err);
        });
    });
});