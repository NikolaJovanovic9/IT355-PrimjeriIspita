package com.met.it355;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class It355Application {

	public static void main(String[] args) {
		SpringApplication.run(It355Application.class, args);
	}

}
