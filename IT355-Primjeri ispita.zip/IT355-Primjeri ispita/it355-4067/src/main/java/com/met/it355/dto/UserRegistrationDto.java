package com.met.it355.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

@Data
@NoArgsConstructor
@AllArgsConstructor

@ToString
public class UserRegistrationDto {

    @NotBlank(message = "Ime je obavezno")
    private String firstName;
    @NotBlank(message = "Prezime je obavezno")
    private String lastName;
    @Email(message = "Email adresa mora biti u validnom formatu")
    private String email;
    @Min(value = 6, message = "Lozinka mora imati barem 6 karaktera")
    private String password;


}
