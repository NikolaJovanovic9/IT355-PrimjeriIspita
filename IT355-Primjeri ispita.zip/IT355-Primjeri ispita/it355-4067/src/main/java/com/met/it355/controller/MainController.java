package com.met.it355.controller;

import com.met.it355.model.Product;
import com.met.it355.model.Reservation;
import com.met.it355.model.User;
import com.met.it355.service.ProductService;
import com.met.it355.service.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@Controller
public class MainController {

    private final UserService userService;
    private final ProductService productService;

    public MainController(UserService userService, ProductService productService) {
        this.userService = userService;
        this.productService = productService;
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    /*
    @GetMapping("/reservedProduct")
    public String index(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        System.out.println(auth.getName());
        User user = userService.getByEmail(auth.getName());

        System.out.println( user);

        List<Product> allProducts = productService.getAll();

        System.out.println( user.getReservations());

        model.addAttribute("reservedProducts", user.getReservations());
        System.out.println(model);

        return "index";
    }

     */
    @GetMapping("/reservedProduct")
    public String showAvailableP(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userService.getByEmail(auth.getName());

        System.out.println(user.getEmail());
        System.out.println(user.getId());
        List<Product> allProducts = productService.getAll();
        List<Product> userProducts = user.getReservations().stream().map(reservation -> reservation.getProduct()).collect(Collectors.toList());

        allProducts.removeAll(userProducts);

        model.addAttribute("userId", user.getId());
        model.addAttribute("products", allProducts);

        return "index";
    }

    @GetMapping("/productList")
    public String showAvailableProducts(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userService.getByEmail(auth.getName());

        List<Product> allProducts = productService.getAll();
        List<Product> userProducts = user.getReservations().stream().map(reservation -> reservation.getProduct()).collect(Collectors.toList());

        allProducts.removeAll(userProducts);

        model.addAttribute("userId", user.getId());
        model.addAttribute("products", allProducts);

        return "product";
    }

}
