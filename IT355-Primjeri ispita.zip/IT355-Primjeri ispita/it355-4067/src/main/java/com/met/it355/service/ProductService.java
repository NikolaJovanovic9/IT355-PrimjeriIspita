package com.met.it355.service;

import com.met.it355.model.Product;
import com.met.it355.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public void create(Product product) {
        if (productRepository.findByTitle(product.getTitle()) == null) {
            productRepository.save(product);
        }
    }

    public List<Product> getAll() {
        return productRepository.findAll();
    }

    public Product findById(int id) {
        return productRepository.findById(id).get();
    }

    public void delete(Product product) {
        productRepository.delete(product);
    }
}
