package com.met.it355.service;

import com.met.it355.model.Product;
import com.met.it355.model.Reservation;
import com.met.it355.model.User;
import com.met.it355.repository.ProductRepository;
import com.met.it355.repository.ReservationRepository;
import com.met.it355.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class ReservationService {

    private final ReservationRepository reservationRepository;
    private final UserRepository userRepository;
    private final ProductRepository productRepository;

    public ReservationService(ReservationRepository reservationRepository, UserRepository userRepository, ProductRepository productRepository) {
        this.reservationRepository = reservationRepository;
        this.userRepository = userRepository;
        this.productRepository = productRepository;
    }

    public void create(int userId, int carId) {
        User user = userRepository.findById(userId).get();
        Product product = productRepository.findById(carId).get();

        Reservation reservation = new Reservation();
        reservation.setUser(user);
        reservation.setProduct(product);
        reservation.setReservationDate(LocalDate.now());
        System.out.println("LD"+reservation.getReservationDate()+" User: "+reservation.getUser().getId()+" Prod: "+reservation.getProduct().getId());

        reservationRepository.save(reservation);
    }

    public void delete(int id) {
        Reservation reservation = reservationRepository.findById(id).get();

        reservationRepository.delete(reservation);
    }

}
