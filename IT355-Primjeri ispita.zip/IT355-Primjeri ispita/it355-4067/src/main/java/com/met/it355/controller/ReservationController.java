package com.met.it355.controller;

import com.met.it355.service.ReservationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/reservations")
public class ReservationController {

    private final ReservationService reservationService;

    public ReservationController(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    @PostMapping
    public ResponseEntity<String> createReservation(@RequestParam(name = "userId") int userId,
                                                    @RequestParam(name = "productId") int productId) {
        reservationService.create(userId, productId);
        return new ResponseEntity<>("Rezervacija je kreirana.", HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteReservation(@PathVariable(name = "id") int id) {
        reservationService.delete(id);
        return new ResponseEntity<>("Rezervacija je obrisana.", HttpStatus.CREATED);
    }

}
