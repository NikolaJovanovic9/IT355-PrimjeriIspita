package com.met.it355;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class It355ApplicationTests {

	@Test
	void contextLoads() {
	}

}
