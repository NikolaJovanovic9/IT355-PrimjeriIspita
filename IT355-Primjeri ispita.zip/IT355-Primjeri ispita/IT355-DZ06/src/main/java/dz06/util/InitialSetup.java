package dz06.util;

import dz06.entity.Ispit;
import dz06.jpa.repository.IspitRepository;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.Arrays;

@Service
public class InitialSetup {

    private final IspitRepository ispitRepository;

    public InitialSetup(IspitRepository ispitRepository) {
        this.ispitRepository = ispitRepository;
    }

    @PostConstruct
    public void initialize() {
        if (ispitRepository.count() == 0) {
            ispitRepository.saveAll(Arrays.asList(
                    new Ispit(Long.valueOf("1"), "CS330", "Razvoj mobilnih aplikacija"),
                    new Ispit(Long.valueOf("2"), "CS450", "Klaud kompjuting"),
                    new Ispit(Long.valueOf("3"), "IT255", "Veb sistemi 1"),
                    new Ispit(Long.valueOf("4"), "IT355", "Veb sistemi 2"),
                    new Ispit(Long.valueOf("5"), "SE311", "Projektovanje i arhitektura softvera"),
                    new Ispit(Long.valueOf("6"), "SE321", "Obezbedjenje kvaliteta i testiranje softvera"),
                    new Ispit(Long.valueOf("7"), "SE322", "Inžinjering zahteva"),
                    new Ispit(Long.valueOf("8"), "SE325", "Upravljanje projektima razvoja softvera")
            ));
        }
    }
}

