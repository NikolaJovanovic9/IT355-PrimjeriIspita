package dz06.service;

import dz06.entity.Student;
import dz06.jpa.repository.StudentRepository;
import dz06.security.MyUserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service("userDetailsService")
public class MyUserDetailsService implements UserDetailsService {
    @Autowired
    private StudentRepository studentRepo;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        Student student = studentRepo.findByEmail(email);

        if (student == null) {
            throw new UsernameNotFoundException("Student nije pronadjen");
        }

        return new MyUserDetails(student);
    }

}
