package dz06.controller;

import dz06.entity.Ispit;
import dz06.entity.Student;
import dz06.jpa.repository.IspitRepository;
import dz06.jpa.repository.StudentRepository;
import dz06.security.MyUserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class IspitController {

    List<Ispit> listaDostupnihIspita = new ArrayList<Ispit>();
    List<Ispit> listaPrijavljenihIspita = new ArrayList<Ispit>();

    @Autowired
    private StudentRepository studentRepo;

    @Autowired
    private IspitRepository ispitRepo;

    @GetMapping({"/prijavi", "/"})
    String getIspiti(Model model) {

        model.addAttribute("myispit", new Ispit());

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        MyUserDetails customUser = (MyUserDetails) auth.getPrincipal();
        long userId = customUser.getUserId();

        Student s1 = studentRepo.getById(userId);


        listaPrijavljenihIspita = s1.getPrijavljeniIspiti();
        listaDostupnihIspita = filtrirajIspite(ispitRepo.findAll(), listaPrijavljenihIspita);

        //System.out.println("trenutni id je " + userId);
        model.addAttribute("prijavljeniIspiti", listaPrijavljenihIspita);
        model.addAttribute("ispiti", listaDostupnihIspita);

        return "prijava";
    }

    @PostMapping("/dodaj")
    String prijaviIspit(@ModelAttribute Ispit ispitDodat,Model model) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        MyUserDetails customUser = (MyUserDetails) auth.getPrincipal();
        long userId = customUser.getUserId();


        Student s1 = studentRepo.getById(userId);
        listaPrijavljenihIspita = s1.getPrijavljeniIspiti();

        Ispit ispitTemp = ispitRepo.getById(ispitDodat.getId());
        listaPrijavljenihIspita.add(ispitTemp);

        listaPrijavljenihIspita = s1.getPrijavljeniIspiti();
        model.addAttribute("prijavljeniIspiti", listaPrijavljenihIspita);

        s1.setPrijavljeniIspiti(listaPrijavljenihIspita);
        studentRepo.save(s1);

        return "prijavljeni.html";
    }

    public List<Ispit> filtrirajIspite(List<Ispit> dostupniIspiti, List<Ispit> prijavljeniIspiti) {

        List<Ispit> rezultat = new ArrayList<>();
        for (Ispit element : dostupniIspiti) {
            if (!prijavljeniIspiti.contains(element)) {
                rezultat.add(element);
            }
        }
        return rezultat;
    }

}
