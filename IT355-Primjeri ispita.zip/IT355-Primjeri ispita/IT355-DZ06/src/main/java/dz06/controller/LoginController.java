package dz06.controller;

import dz06.entity.Student;
import dz06.jpa.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.validation.Valid;

@Controller
public class LoginController {

    @Autowired
    PasswordEncoder passEncoder;
    @Autowired
    private StudentRepository userRepository;


    @GetMapping("/login")
    String getLogin(Model model) {
        return "login";
    }

    @GetMapping("/register")
    String registerPage(Model model) {
        model.addAttribute("student", new Student());
        return "register";
    }

    @PostMapping(path = "/register")
    public String registerUserAccount(
            @ModelAttribute("student") @Valid Student user, BindingResult bindingResult, Model model) {


        if (userRepository.existsByEmail(user.getEmail()) || bindingResult.hasErrors()) {
            bindingResult.reject("Ne", "email");

            return "register";
        }
        user.setPassword(passEncoder.encode(user.getPassword()));
        userRepository.save(user);
        return "redirect:/login";

    }

}
