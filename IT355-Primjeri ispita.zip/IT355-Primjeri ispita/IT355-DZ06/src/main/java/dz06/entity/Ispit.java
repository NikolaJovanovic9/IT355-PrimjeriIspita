package dz06.entity;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.stereotype.Component;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Data
@ToString
@NoArgsConstructor
@Component
@Entity
public class Ispit {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String naziv;
    private String sifra;


    public Ispit(Long id, String naziv, String sifra) {
        super();
        this.id = id;
        this.naziv = naziv;
        this.sifra = sifra;
    }

    public Ispit(String naziv, String sifra) {
        super();
        this.naziv = naziv;
        this.sifra = sifra;
    }

}
