package dz06.entity;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.format.annotation.NumberFormat;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.Size;
import java.util.ArrayList;
import java.util.List;

@Data
@ToString
@NoArgsConstructor
@Component
@Entity(name = "student")
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "student_ispiti",
            joinColumns = {@JoinColumn(name = "student_id")},
            inverseJoinColumns = {@JoinColumn(name = "ispit_id")})
    private List<Ispit> prijavljeniIspiti = new ArrayList<>();
    @Size(min = 1)
    private String ime;
	@Size(min = 1)
	private String prezime;
    @Size(min = 4, max = 5)
    @NumberFormat
    private String indeks;
    @Email
    @Size(min = 1)
    @Column(unique = true)
    private String email;
    @Size(min = 5)
    private String password;

    public Student(Long id, String ime, String prezime, String indeks, String email, String password) {
        super();
        this.id = id;
        this.ime = ime;
		this.prezime = prezime;
        this.indeks = indeks;
        this.email = email;
        this.password = password;

    }

    public Student(String ime, String indeks) {
        super();
        this.ime = ime;
        this.indeks = indeks;

    }

}
