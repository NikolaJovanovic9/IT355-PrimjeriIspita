package ispitjunb.ispit4067.service;

import ispitjunb.ispit4067.entity.Korisnik;
import ispitjunb.ispit4067.repository.KorisnikRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class KorisnikService {

    @Autowired
    KorisnikRepository korisnikRepository;

    public Korisnik insertKorisnik(Korisnik korisnik) {
        return korisnikRepository.save(korisnik);
    }


    public List<Korisnik> fetchAll() {
        return korisnikRepository.findAll();
    }

    public Korisnik findKorisnik(int id) {

        Optional<Korisnik> korisnik = korisnikRepository.findById(id);
        if (korisnik.isPresent()) {
            return korisnik.get();
        }
        return null;
    }

    public Korisnik updateKorisnik(int id, Korisnik korisnik) {
        korisnik.setId(id);
        return korisnikRepository.save(korisnik);
    }

    public void deleteById(int id) {
        korisnikRepository.deleteById(id);
    }

}
