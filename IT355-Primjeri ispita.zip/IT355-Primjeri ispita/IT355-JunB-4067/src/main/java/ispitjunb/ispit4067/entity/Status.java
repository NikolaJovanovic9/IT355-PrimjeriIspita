package ispitjunb.ispit4067.entity;

public enum Status {
    TRAJE,ZAVRSEN
}
