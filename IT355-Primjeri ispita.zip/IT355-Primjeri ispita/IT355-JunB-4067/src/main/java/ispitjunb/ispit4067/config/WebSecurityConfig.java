package ispitjunb.ispit4067.config;


import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Override
    public void configure(HttpSecurity http) throws Exception {
        //odkomentarisite donju liniju i zakomentarisite ostale radi omogucavanja pristupa svima
        http.csrf().disable().cors().and().authorizeRequests().anyRequest().permitAll();

        //httpSecurity.authorizeRequests()
          //      .antMatchers("/slobodniMobilni").access("hasAuthority('KUPAC')")
            //    .antMatchers("/mobilni").access("hasAuthority('PRODAVAC')")
              //  .antMatchers("/updateMobilni/**").access("hasAuthority('PRODAVAC')")
                //.antMatchers("/slobodniMobilni").access("hasAuthority('PRODAVAC')");

        //httpSecurity.authorizeRequests().antMatchers("/mobilni").access("hasAuthority('ADMIN')");

    }
}