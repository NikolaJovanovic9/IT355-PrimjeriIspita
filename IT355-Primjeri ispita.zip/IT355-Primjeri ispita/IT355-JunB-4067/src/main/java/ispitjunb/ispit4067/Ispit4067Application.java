package ispitjunb.ispit4067;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ispit4067Application {

    public static void main(String[] args) {
        SpringApplication.run(Ispit4067Application.class, args);
    }

}
