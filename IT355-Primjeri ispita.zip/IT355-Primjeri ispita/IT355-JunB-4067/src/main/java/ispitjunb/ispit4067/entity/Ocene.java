package ispitjunb.ispit4067.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;

@Data
@ToString
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Ocene {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @ManyToOne
    private Korisnik korisnik;

    @ManyToOne
    private Dogadjaj dogadjaj;

    private int ocena;
}
