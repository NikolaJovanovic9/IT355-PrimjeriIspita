package ispitjunb.ispit4067.service;

import ispitjunb.ispit4067.entity.Dogadjaj;
import ispitjunb.ispit4067.repository.DogadjajRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DogadjajService {

    @Autowired
    DogadjajRepository dogadjajRepository;

    public Dogadjaj addDogadjaj(Dogadjaj dogadjaj){
        //System.out.println("Evo ga dogadjaj "+ dogadjaj.toString());
        return dogadjajRepository.save(dogadjaj);
    }

    public List<Dogadjaj> fetchAll() {
        return dogadjajRepository.findAll();
    }


}
