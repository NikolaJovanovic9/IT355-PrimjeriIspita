package ispitjunb.ispit4067.repository;

import ispitjunb.ispit4067.entity.Dogadjaj;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DogadjajRepository extends JpaRepository<Dogadjaj, Integer> {
}
