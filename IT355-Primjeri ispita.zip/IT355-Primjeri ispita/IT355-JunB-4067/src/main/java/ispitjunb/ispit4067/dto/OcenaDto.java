package ispitjunb.ispit4067.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OcenaDto {

    private int korisnik_id;
    private int dogadjaj_id;

}
