package ispitjunb.ispit4067.controller;

import ispitjunb.ispit4067.entity.Dogadjaj;
import ispitjunb.ispit4067.service.DogadjajService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
public class DogadjajController {

    @Autowired
    DogadjajService dogadjajService;

    @PostMapping(path = "/addDogadjaj")//
    public ResponseEntity insertKorisnik(@RequestBody Dogadjaj dogadjaj) {
        dogadjaj.setEvent_tim(new Date());
        return ResponseEntity.ok(dogadjajService.addDogadjaj(dogadjaj));
    }

    @GetMapping(path = "/dogadjaji")//
    public ResponseEntity getKorisnici() {
        return ResponseEntity.ok(dogadjajService.fetchAll());
    }


}
