package ispitjunb.ispit4067.entity;

public enum Tip {
    CONCERT, UTAKMICA
}
