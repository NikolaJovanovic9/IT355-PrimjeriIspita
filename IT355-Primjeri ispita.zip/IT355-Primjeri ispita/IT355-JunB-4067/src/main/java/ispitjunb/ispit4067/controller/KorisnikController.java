package ispitjunb.ispit4067.controller;

import ispitjunb.ispit4067.entity.Korisnik;
import ispitjunb.ispit4067.service.KorisnikService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@RestController
public class KorisnikController {

    @Autowired
    KorisnikService korisnikService;

    @PostMapping(path = "/addKorisnik")//
    public ResponseEntity insertKorisnik(@RequestBody Korisnik korisnik) {
        korisnik.setDateOfRegistration(new Date());
        return ResponseEntity.ok(korisnikService.insertKorisnik(korisnik));
    }

    @GetMapping(path = "/korisnici")//
    public ResponseEntity getKorisnici() {
        return ResponseEntity.ok(korisnikService.fetchAll());
    }


    @GetMapping(path = "/korisnik/{id}")
    public ResponseEntity getKorisnik(@PathVariable("id") Integer id) {
        return ResponseEntity.ok(korisnikService.findKorisnik(id));
    }

    @DeleteMapping("/deleteKorisnik/{id}")//
    public boolean deleteById(@PathVariable("id") Integer id) {
        korisnikService.deleteById(id);
        return true;
    }

    @PutMapping(path = "/updateKorisnik/{id}")//
    public ResponseEntity updateKorisnik(@PathVariable int id, @RequestBody Korisnik korisnik) {

        korisnik.setDateOfRegistration(new Date());
        return ResponseEntity.ok(korisnikService.updateKorisnik(id, korisnik));
    }
}
